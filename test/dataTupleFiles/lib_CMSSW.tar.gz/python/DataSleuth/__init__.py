__path__.append('/cvmfs/cms.cern.ch/slc6_amd64_gcc491/cms/cmssw-patch/CMSSW_7_4_4_patch1/python/DataSleuth')
